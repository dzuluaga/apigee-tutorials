Parallel Promise NodeJS API Proxy
==================================================



#### Test Local

```bash
curl http://localhost:3000/albums\?artists\[\]=depeche+mode\&artists\[\]=radiohead\&artists\[\]\=phoenix -v --globoff
```

#### Test on Edge


#### Deploy to Edge

##### Grab Zip file and Deploy

##### Deploy with ApigeeTool

