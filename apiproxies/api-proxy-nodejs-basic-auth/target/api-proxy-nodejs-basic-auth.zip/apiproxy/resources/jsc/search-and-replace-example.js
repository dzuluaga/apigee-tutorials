function testFunction(){
	'use strict';
	var test = "Sun Mar 29 2015 13:30:46_test";
	return test;
}
//remove comment to see jshint triggering errors
//var a = "test";
/*if(1 === 1) {
	if(2 === 2) {
		if(3 === 3) {
			if(4 === 4) {

			}
		}
	}

}*/

testFunction();