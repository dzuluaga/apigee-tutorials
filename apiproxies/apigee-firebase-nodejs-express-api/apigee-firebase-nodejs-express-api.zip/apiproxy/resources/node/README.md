apigee-firebase-nodejs-express-api
==================================

Run and Deploy
======
#### Run locally
```bash
$ npm install
```

#### Deploy to Apigee Edge
```

```

Run
===
```bash
$ apiKey={GET_FROM_FIREBASE_CONSOLE}
 authDomain={GET_FROM_FIREBASE_CONSOLE} databaseURL={GET_FROM_FIREBASE_CONSOLE} projectId={GET_FROM_FIREBASE_CONSOLE} messagingSende
rId={GET_FROM_FIREBASE_CONSOLE} node index.js
```
Test
====

#### Create Records in Firebase

```javascript
app.post('/products', function (req, res) {
  var ref = firebase.database().ref('/products');
  var obj = [{
      id: "123",
      description: "Android Newborn Pacifier"
    },
    {
      id: "345",
      description: "Android Pixel"
    },
    {
      id: "223",
      description: "Chromecast Ultra"
    }
  ];
  res.send(ref.push(obj)); // Creates a new ref with a new "push key"
  ref.set(obj); // Overwrites the path
  ref.update(obj); // Updates only the specified attributes
})
```

Execute this command:
```
curl http://localhost:3000/products -X POST

```
![alt text](/images/create_arrays_in_firebase.png "create array in firebase")

#### Read records from Firebase

```bash
$ curl -X GET http://localhost:3000/products

Returns:

[{"description":"Android Newborn Pacifier","id":"123"},{"description":"Android Pixel","id":"345"},{"description":"Chromecast Ultra","id":"223"}]
```